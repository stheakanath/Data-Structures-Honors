//Sony Theakanath
//Inherits-Asg1: In Class Lab: Design Patterns

package org.bcp.Theakanath;

/**
	ChildlessStudent has the same functionalities as Student
	except there can not be any subclasses.
*/

public final class ChildlessStudent extends Student
{
	/**
		Constructor
	*/
	public ChildlessStudent(String setfirstname, String setlastname, int year)
	{
		super(setfirstname, setlastname, year);
	}
}
