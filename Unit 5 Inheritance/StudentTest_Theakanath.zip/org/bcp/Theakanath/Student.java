//Sony Theakanath
//Inherits-Asg1: In Class Lab: Design Patterns

package org.bcp.Theakanath;

/**
	Student has the same functionalites as Person except it can
	have a year added to the student and be added to his 
	id.
*/
public class Student extends Person
{
	/**
		Default constructor
	*/
	public Student(String setfirstname, String setlastname, int year)
	{
		super(setfirstname, setlastname);
		int together = Integer.parseInt("" + year + super.getId());
		changeid(together);
	}
	
	/**
		Checks if two students are equal
	*/
	public boolean equals(Student student)
	{
		if(student.getId() == super.getId())
			return true;
		return false;
	}
	
	/**
		Returns the student's name and their id
	*/
	public String toString()
	{
		return ("Name: " + super.getFirstName() + " " + super.getLastName() + " Id: " + super.getId());
	}
}

/**
	Person creates a person with a first name, last name and it
	keeps track of the number of persons based on the program.
	
	Taken from last program and not modified.
*/
class Person
{
	private String firstname;
	private String lastname;
	private String name;
	private static int numpersons = 1;
	private int id;
	
	/**
		Default constructor
		Preconditons: There is a first and last name
	*/
	public Person(String setfirstname, String setlastname)
	{
		firstname = setfirstname;
		lastname = setlastname;
		id = numpersons;
		numpersons++;
	}
	
	/**
		Changes the persons fullname
		Preconditions: It's a full name
	*/
	public void changeName(String newname)
	{
		name = newname;
	}
	
	/**
		Changes the persons lastname
		Preconditions: It's a last name
	*/
	public void changeLastName(String newlast)
	{
		lastname = newlast;
	}
	
	/**
		Changes the persons first name
		Preconditions: It's a first name
	*/
	public void changeFirstName(String newfirst)
	{
		firstname = newfirst;
	}
	
	/**
		Changes the person's id
		Preconditions: there is an id, parameter
	*/
	public void changeid(int newid)
	{
		id = newid;
	}
	
	/**
		returns the person's first and last name together.
		Preconditions: none
	*/
	public String getName()
	{
		return firstname +  " " + lastname;
	}
	
	/**
		Returns the person's last name
		Preconditions: none
	*/
	public String getLastName()
	{
		return lastname;
	}
	
	/**
		Returns the person's first name
		Preconditions: none
	*/
	public String getFirstName()
	{
		return firstname;
	}
	
	/**
		Returns the person's id
		Preconditions: None
	*/
	public int getId()
	{
		return id;
	}
	
	/**
		Returns the number of people
		Preconditions: none
	*/
	public int getPeople()
	{
		return numpersons;
	}
	
	/**
		Class invariant, this combines the last name with the persons lastname.
		Preconditions: spouse has name
	*/
	public void marry(Person spouse)
	{
		lastname = spouse.getLastName();
	}
}